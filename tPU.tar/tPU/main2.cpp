#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

int main(){
    int r0=1;
    int r1=1;
    int r2=2;
    int r5=10;
    int r6;
    r5=r5-r2;

    while(r5){
    r6=r0+r1;
    r1=r0;
    r0=r6;
    r5--;
    }

    cout <<"R0:" <<r0<<endl;
    cout <<"R1:" <<r1<<endl;
    cout <<"R2:" <<r2<<endl;
    cout <<"R5:" <<r5<<endl;
    cout <<"R6:" <<r6<<endl;
    return 0;

}
